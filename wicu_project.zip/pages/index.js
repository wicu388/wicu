
export default function Home() {
  return (
    <div style={{fontFamily:"sans-serif", padding:"40px"}}>
      <h1>WICU – Tienda IA 24/7</h1>
      <p>Proyecto base listo para desplegar en Vercel.</p>
    </div>
  );
}
